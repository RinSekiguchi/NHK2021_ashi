#include <M5Stack.h>
#include "define.h"

void initDisplay();
void initSpriteArea();
void refreshDisplay();
void printVelData();
void printPosiData();

void dispConnectionState(bool);
void dispRobotState();
