# GRpeachBoard
注)この資料は一般向けではなく，プロジェクトメンバーに向けたものです．
プロジェクトメンバー以外からの質問等には一切答えません．

以下は導入資料
https://docs.google.com/presentation/d/1vFQVnCq1d7KiPc60Wszn75yHT0mIpJ_uGsxWUq_rMWI/edit?usp=sharing

※プロジェクトメンバーのみアクセス可
